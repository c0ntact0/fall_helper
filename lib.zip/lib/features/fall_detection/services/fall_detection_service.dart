import 'dart:async';
import 'dart:math';

import 'package:sensors_plus/sensors_plus.dart';

import '../domain/models/fall_detection_settings.dart';
import '../domain/models/fall_event.dart';

class FallDetectionService {
  FallDetectionService({
    FallDetectionSettings settings = const FallDetectionSettings.defaults(),
  }) : _settings = settings;

  final FallDetectionSettings _settings;

  StreamSubscription<UserAccelerometerEvent>? _userAccelerometerSubscription;
  StreamSubscription<GyroscopeEvent>? _gyroscopeSubscription;

  bool _isRunning = false;
  bool get isRunning => _isRunning;

  DateTime? _impactDetectedAt;
  double _impactMagnitude = 0.0;
  bool _rotationConfirmed = false;

  /// Estado do sensor, não do candidato atual.
  bool _gyroAvailable = true;

  DateTime? _immobilityStartedAt;
  DateTime? _cooldownUntil;

  Future<void> start({
    required Future<void> Function(FallEvent event) onFallDetected,
    void Function(Object error)? onError,
  }) async {
    if (_isRunning) return;

    _resetCandidate();

    _userAccelerometerSubscription =
        userAccelerometerEventStream(
          samplingPeriod: SensorInterval.gameInterval,
        ).listen(
          (event) async {
            try {
              await _handleUserAccelerometerEvent(
                event,
                onFallDetected: onFallDetected,
              );
            } catch (error) {
              onError?.call(error);
            }
          },
          onError: (error) {
            onError?.call(error);
          },
          cancelOnError: false,
        );

    _gyroscopeSubscription =
        gyroscopeEventStream(
          samplingPeriod: SensorInterval.gameInterval,
        ).listen(
          (event) {
            _handleGyroscopeEvent(event);
          },
          onError: (error) {
            _gyroAvailable = false;
            onError?.call(error);
          },
          cancelOnError: false,
        );

    _isRunning = true;
  }

  Future<void> stop() async {
    await _userAccelerometerSubscription?.cancel();
    await _gyroscopeSubscription?.cancel();
    _userAccelerometerSubscription = null;
    _gyroscopeSubscription = null;
    _isRunning = false;
    _resetCandidate();
  }

  Future<void> _handleUserAccelerometerEvent(
    UserAccelerometerEvent event, {
    required Future<void> Function(FallEvent event) onFallDetected,
  }) async {
    final now = DateTime.now();

    if (_cooldownUntil != null && now.isBefore(_cooldownUntil!)) {
      return;
    }

    final accelerationMagnitude = _magnitude(event.x, event.y, event.z);

    if (_impactDetectedAt == null) {
      if (accelerationMagnitude >= _settings.impactThresholdMs2) {
        _impactDetectedAt = now;
        _impactMagnitude = accelerationMagnitude;
        _rotationConfirmed = false;
        _immobilityStartedAt = null;
      }
      return;
    }

    final elapsedSinceImpact = now.difference(_impactDetectedAt!);

    if (elapsedSinceImpact > _settings.immobilityWindow) {
      _resetCandidate();
      return;
    }

    if (accelerationMagnitude <= _settings.immobilityThresholdMs2) {
      _immobilityStartedAt ??= now;

      final immobilityDuration = now.difference(_immobilityStartedAt!);

      final bool canConfirmWithoutGyro = !_gyroAvailable;
      final bool motionConfirmed = _rotationConfirmed || canConfirmWithoutGyro;

      if (motionConfirmed &&
          immobilityDuration >= _settings.immobilityRequiredDuration) {
        final fallEvent = FallEvent(
          detectedAt: now,
          impactMagnitude: _impactMagnitude,
          rotationConfirmed: _rotationConfirmed,
          immobilityDuration: immobilityDuration,
        );

        _cooldownUntil = now.add(_settings.cooldown);
        _resetCandidate();

        await onFallDetected(fallEvent);
      }
    } else {
      _immobilityStartedAt = null;
    }
  }

  void _handleGyroscopeEvent(GyroscopeEvent event) {
    if (_impactDetectedAt == null) return;

    final now = DateTime.now();
    final elapsedSinceImpact = now.difference(_impactDetectedAt!);

    if (elapsedSinceImpact > _settings.rotationWindow) {
      return;
    }

    final rotationMagnitude = _magnitude(event.x, event.y, event.z);

    if (rotationMagnitude >= _settings.rotationThresholdRadS) {
      _rotationConfirmed = true;
    }
  }

  double _magnitude(double x, double y, double z) {
    return sqrt(x * x + y * y + z * z);
  }

  void _resetCandidate() {
    _impactDetectedAt = null;
    _impactMagnitude = 0.0;
    _rotationConfirmed = false;
    _immobilityStartedAt = null;
  }

  Future<void> dispose() async {
    await stop();
  }
}
